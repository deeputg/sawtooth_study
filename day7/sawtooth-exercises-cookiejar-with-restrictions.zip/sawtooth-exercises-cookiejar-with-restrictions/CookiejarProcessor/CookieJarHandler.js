/**
 * Copyright 2018 Intel Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ------------------------------------------------------------------------------
 */

//works in strict mode
'use strict'

//require the handler module.
//declaring a constant variable.
const { TransactionHandler } = require('sawtooth-sdk/processor/handler')


const {
  InvalidTransaction,
  InternalError
} = require('sawtooth-sdk/processor/exceptions')
const crypto = require('crypto')
const {TextEncoder, TextDecoder} = require('text-encoding/lib/encoding')
const protobuf = require('protobufjs');
const Long = require('long');

const _hash = (x) => crypto.createHash('sha512').update(x).digest('hex').toLowerCase().substring(0, 64)
var encoder = new TextEncoder('utf8')
var decoder = new TextDecoder('utf8')
const MIN_VALUE = 0
const SW_FAMILY = 'cookiejar'
const SW_NAMESPACE = _hash(SW_FAMILY).substring(0, 6)
const BI_NAMESPACE      = '00b10c00'
const BI_CONFIG_ADDRESS = '00b10c0100000000000000000000000000000000000000000000000000000000000000'

//function to obtain the payload obtained from the client
const _decodeRequest = (payload) =>
  new Promise((resolve, reject) => {
    payload = payload.toString().split(',')
    if (payload.length === 2) {
      resolve({
        action: payload[0],
        quantity: payload[1]
      })
    }
   
    else {
      let reason = new InvalidTransaction('Invalid payload serialization')
      reject(reason)
    }
})

if (!String.prototype.padStart) {
  String.prototype.padStart = function padStart(targetLength, padString) {
      targetLength = targetLength >> 0; //truncate if number, or convert non-number to 0;
      padString = String(typeof padString !== 'undefined' ? padString : ' ');
      if (this.length >= targetLength) {
          return String(this);
      } else {
          targetLength = targetLength - this.length;
          if (targetLength > padString.length) {
              padString += padString.repeat(targetLength / padString.length); //append to original to ensure we are longer than needed
          }
          return padString.slice(0, targetLength) + String(this);
      }
  };
}

const getBlockSpecificAddress = (blockNumber) => {
  return BI_NAMESPACE + blockNumber.toString(16).slice(0, 2).padStart(62, "0");
}

const getBlockInfo = (context) => {
  return new Promise((resolve, reject) => {
    context.getState([BI_CONFIG_ADDRESS])
      .then(blockInfoConfigState => {
        protobuf.load("block_info.proto", function(err, root) {
          if(err) throw err;
          const blockInfoConfigProto = root.lookupType("Block_Info.BlockInfoConfig");
          const blockInfoProto = root.lookupType("Block_Info.BlockInfo");
  
          // Get blockInfo config
          const configMessage = blockInfoConfigProto.decode(blockInfoConfigState[BI_CONFIG_ADDRESS]);
          const config = blockInfoConfigProto.toObject(configMessage);
          console.log("blockInfoConfig", config);
          const latestBlockNumber = config.latestBlock;
  
          // Create blockInfo address
          const blockInfoAddress = getBlockSpecificAddress(latestBlockNumber);
          console.log("blockInfoAddress", blockInfoAddress);
          
          // Get Block Info for latest block
          context.getState([blockInfoAddress])
            .then((blockInfoState) => {
              const blockInfoMessage = blockInfoProto.decode(blockInfoState[blockInfoAddress]);
              let blockInfo = blockInfoProto.toObject(blockInfoMessage);
              console.log("blockInfo", blockInfo);
              resolve(blockInfo);
            })
        })
      });
  })
}

//function to display the errors
const _toInternalError = (err) => {
  console.log(" in error message block")
  let message = err.message ? err.message : err
  throw new InternalError(message)
}

//function to set the entries in the block using the "SetState" function
const _setEntry = (context, address, stateValue) => {
  let dataBytes = encoder.encode(stateValue)
  let entries = {
    [address]: dataBytes 
  }
  return context.setState(entries)
}

//function to bake a cookie
const makeBake =(context, address, quantity, userPK)  => (possibleAddressValues) => {
  console.log("getBlockInfo", getBlockInfo);
  return getBlockInfo(context).then(blockInfo => {
    console.log("blockInfo_makeBake", blockInfo);
    let stateValueRep = possibleAddressValues[address]
    let newCount = 0
    let cookieState;
    if (stateValueRep == null || stateValueRep == ''){
      console.log("No previous cookies, creating new cookie jar ")
      newCount = quantity
      cookieState = {
        count: newCount,
        timestamp: blockInfo.timestamp.toNumber()
      }
    }
    else{
      let cookieStateDecoded = decoder.decode(stateValueRep)
      cookieState = JSON.parse(cookieStateDecoded);
      console.log("blockInfo.timestamp", blockInfo.timestamp);
      console.log("cookieState.timestamp", cookieState.timestamp);
      console.log("blockInfo.timestamp.toNumber() < (cookieState.timestamp + 30)", 
        blockInfo.timestamp.toNumber() < (cookieState.timestamp + 30));
      if(blockInfo.timestamp.toNumber() < (cookieState.timestamp + 30))
      {
        throw new InvalidTransaction("Too soon to bake cookies_1");
      }
      newCount = parseInt(cookieState.count) + quantity
      cookieState = {
        count: newCount,
        timestamp: blockInfo.timestamp.toNumber()
      }
  }
  let newState = JSON.stringify(cookieState);
  return _setEntry(context, address, newState)
  })
  
}

//function to eat a cookie
const makeEat =(context, address, quantity, userPK)  => (possibleAddressValues) => {
  let stateValueRep = possibleAddressValues[address]
  let newCount = 0
  let count
  let cookieState;
  if (stateValueRep == null || stateValueRep == ''){
    newCount = quantity
  }
  else{
    let cookieStateDecoded = decoder.decode(stateValueRep);
    cookieState = JSON.parse(cookieStateDecoded);
    count = parseInt(cookieState.count)
    if (count < quantity){
      throw new InvalidTransaction(`Not enough cookies to eat.The number should be lesser or equal to ${count}`)
    }
    newCount = count - quantity;
    cookieState.count = newCount;
    console.log("Cookies left:"+newCount)
  }
  let strNewCount = JSON.stringify(cookieState);
  return _setEntry(context, address, strNewCount)
}


class CookieJarHandler extends TransactionHandler{
  constructor(){
    super(SW_FAMILY,['1.0'],[SW_NAMESPACE])
  }
  apply(transactionProcessRequest, context){
    return _decodeRequest(transactionProcessRequest.payload)
    .catch(_toInternalError)
    .then((update) => {
    let header = transactionProcessRequest.header
    let userPublicKey = header.signerPublicKey
    let action = update.action
    if (!update.action) {
      throw new InvalidTransaction('Action is required')
    }
    let quantity = update.quantity
    if (quantity === null || quantity === undefined) {
      throw new InvalidTransaction('Value is required')
    }
    quantity = parseInt(quantity)
    if (typeof quantity !== "number" ||  quantity <= MIN_VALUE) {
      throw new InvalidTransaction(`Value must be an integer ` + `no less than 1`)
    }

    // Select the action to be performed
    let actionFn
    if (update.action === 'bake') { 
      actionFn = makeBake
    }
    else if (update.action === 'eat') {
      actionFn = makeEat 
    } 
    
    else {	
      throw new InvalidTransaction(`Action must be bake or eat `)		
    }

    // Get the current state, for the key's address:
    let Address = SW_NAMESPACE + _hash(userPublicKey).slice(-64)
    let getPromise
    if (update.action == 'bake')
      getPromise = context.getState([Address])
    else
      getPromise = context.getState([Address])
    let actionPromise = getPromise.then(
      actionFn(context,Address, quantity, userPublicKey)
      )
    
    return actionPromise.then(addresses => {
      if (addresses && addresses.length === 0) {
        throw new InvalidTransaction('State Error!')
      }  
    })

   
   
  })
 }
}

module.exports = CookieJarHandler
