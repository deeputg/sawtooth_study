## Stream APIs

# subscriptionProxy.js
    Make a new stream object that connects to validator
    Open a new stream connection
    Register the 'handleEvent' as handler function for messages received
    Make subsciptions using the new connection

# subscriber.js
    Create a simple block commit subscription - getBlockSubscription function
    Create a Client Subscription Request - getClientSubscriptionRequest function
    Send the request to validator using stream object - Use the send API of stream
    Decode the response from the validator - decodeSubscriptionResponse function
    Check if the status. - getSubscriptionStatus function
    If status is not 'OK', throw an error to the caller
    Create a delta subscription that filters cookiejar TP state changes - getStateDelataSubscription

# eventHandler.js
    Check if the message received is an event message - isEventMessage function
    Get the events from the message - getEventsFromMessage function
    Iterate over the events
    For each event, check for the event type - isBlockCommitEvent

## Expected result
The event sidebar should start showing the event messages on new blocks