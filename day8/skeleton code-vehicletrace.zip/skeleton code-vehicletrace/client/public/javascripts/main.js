
function viewData() {
    window.location.href='/listView';

}

function addVehicleAsRegister() {

    // write your logic here ^_^
}

function addVehicleAsManufacturer() {

    // write your logic here ^_^
}